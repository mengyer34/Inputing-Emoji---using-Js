# Known issues

## Chrome rendering issues

[Issue 1310282: Multi skin toned handshake, couple, kiss, holding hands not shaped correctly with Apple Color Emoji](https://bugs.chromium.org/p/chromium/issues/detail?id=1310282&q=emoji&can=2) (Chromium bug tracker)

