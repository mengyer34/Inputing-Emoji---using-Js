# `deleteRecents`

```javascript
import { deleteRecents } from 'picmo';
```

```javascript
deleteRecents(): void
```

Clears the recent emojis list stored in local storage.

THe recents are stored under the local storage key `PicMo:recents`.