# `CategoryKey`

Uniquely identifies one of the supported emoji categories. The valid values are:

- `activities`
- `animals-nature`
- `custom`
- `flags`
- `food-drink`
- `objects`
- `people-body`
- `recents`
- `smileys-emotion`
- `symbols`
- `travel-places`
