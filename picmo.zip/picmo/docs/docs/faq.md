---
sidebar_label: FAQ
---

# Frequently asked questions

## Why are some emojis not rendering correctly?

TBD: discuss emoji versions, OS glyphs/support, browser bugs, etc.
