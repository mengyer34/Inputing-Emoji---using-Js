export const customEmoji: string;
