export const twemoji: string;
