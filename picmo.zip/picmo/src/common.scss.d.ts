export const imagePlaceholder: string;
export const placeholder: string;
export const shine: string;
