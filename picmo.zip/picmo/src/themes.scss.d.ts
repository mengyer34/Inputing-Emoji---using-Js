export const autoTheme: string;
export const darkTheme: string;
export const lightTheme: string;
