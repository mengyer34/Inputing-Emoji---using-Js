export const emojiContainer: string;
