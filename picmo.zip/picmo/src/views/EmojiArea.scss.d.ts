export const emojis: string;
