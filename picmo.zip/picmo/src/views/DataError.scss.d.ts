export const dataError: string;
