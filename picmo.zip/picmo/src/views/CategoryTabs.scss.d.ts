export const categoryButton: string;
export const categoryButtonActive: string;
export const categoryButtons: string;
export const categoryTab: string;
export const categoryTabActive: string;
