export const categoryName: string;
export const emojiCategory: string;
export const noRecents: string;
export const recentEmojis: string;
