export const preview: string;
export const previewEmoji: string;
export const previewName: string;
export const tag: string;
export const tagList: string;
