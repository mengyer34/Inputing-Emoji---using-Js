export const clearButton: string;
export const clearSearchButton: string;
export const notFound: string;
export const searchAccessory: string;
export const searchContainer: string;
export const searchField: string;
export const searchResults: string;
