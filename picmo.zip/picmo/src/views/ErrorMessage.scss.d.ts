export const appear: string;
export const appearGrow: string;
export const error: string;
export const icon: string;
export const title: string;
