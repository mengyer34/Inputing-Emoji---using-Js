export const emoji: string;
