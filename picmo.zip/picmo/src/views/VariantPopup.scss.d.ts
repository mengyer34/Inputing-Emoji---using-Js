export const variantOverlay: string;
export const variantPopup: string;
