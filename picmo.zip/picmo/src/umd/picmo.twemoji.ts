import { TwemojiRenderer } from '../renderers/twemoji';
export default TwemojiRenderer;
