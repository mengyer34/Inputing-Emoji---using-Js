import themes from './themes.scss';

const { autoTheme, lightTheme, darkTheme } = themes;
export { autoTheme, lightTheme, darkTheme };
